# 📱 دليل إنشاء ملف APK للتطبيق

## الطريقة الأولى: استخدام PWABuilder (الأسهل) ⭐

### الخطوات:

1. **افتح موقع PWABuilder**
   - اذهب إلى: https://www.pwabuilder.com

2. **أدخل رابط التطبيق**
   - الصق هذا الرابط: `https://3000-inr2tnb1kga0jf2fmmieo-6532622b.e2b.dev`
   - اضغط على زر "Start"

3. **انتظر التحليل**
   - سيقوم الموقع بفحص التطبيق
   - سيظهر لك تقرير بالمميزات المدعومة

4. **اختر Package for stores**
   - اضغط على "Package for stores"
   - اختر "Android" من القائمة

5. **إعدادات APK**
   - Package ID: `com.abdulrahman.suhaila.wedding`
   - App name: `ذكرى الزواج`
   - App version: `1.0.0`
   - اترك باقي الإعدادات كما هي

6. **تنزيل APK**
   - اضغط "Generate"
   - انتظر حتى ينتهي
   - اضغط "Download" لتنزيل ملف ZIP
   - فك الضغط عن الملف
   - ستجد ملف APK جاهز للتثبيت

---

## الطريقة الثانية: استخدام AppsGeyser 🚀

### الخطوات:

1. **افتح موقع AppsGeyser**
   - اذهب إلى: https://appsgeyser.com

2. **اختر "Website App"**
   - اختر "Create App from Website"

3. **أدخل معلومات التطبيق**
   - URL: `https://3000-inr2tnb1kga0jf2fmmieo-6532622b.e2b.dev`
   - App Name: `ذكرى زواج عبدالرحمن وسهيلة`
   - اضغط "Next"

4. **تخصيص التطبيق**
   - ارفع الأيقونة (icon-512.png)
   - اختر الألوان المناسبة
   - اضغط "Create"

5. **تنزيل APK**
   - أنشئ حساب مجاني
   - انزل ملف APK

---

## الطريقة الثالثة: استخدام Web2APK 📦

### الخطوات:

1. **افتح موقع Web2APK**
   - اذهب إلى: https://www.web2apk.com

2. **أدخل المعلومات**
   - Website URL: `https://3000-inr2tnb1kga0jf2fmmieo-6532622b.e2b.dev`
   - App Name: `Wedding Countdown`
   - Package Name: `com.wedding.countdown`

3. **تخصيص المظهر**
   - ارفع الأيقونة
   - اختر Screen Orientation: Portrait
   - Enable JavaScript: ✅

4. **إنشاء APK**
   - اضغط "Generate APK"
   - انتظر المعالجة
   - انزل الملف

---

## الطريقة الرابعة: استخدام Capacitor (للمطورين) 💻

### تثبيت Capacitor:
```bash
npm install @capacitor/core @capacitor/android @capacitor/cli
npx cap init "Wedding Countdown" "com.abdulrahman.suhaila.wedding"
npx cap add android
```

### إضافة ملف capacitor.config.json:
```json
{
  "appId": "com.abdulrahman.suhaila.wedding",
  "appName": "ذكرى الزواج",
  "webDir": "dist",
  "bundledWebRuntime": false,
  "server": {
    "url": "https://3000-inr2tnb1kga0jf2fmmieo-6532622b.e2b.dev"
  }
}
```

### بناء APK:
```bash
npx cap sync android
npx cap open android
# Build APK from Android Studio
```

---

## 🎯 الطريقة الموصى بها

**استخدم PWABuilder** لأنه:
- ✅ مجاني تماماً
- ✅ سهل الاستخدام
- ✅ ينتج APK محترف
- ✅ يدعم جميع مميزات PWA
- ✅ لا يحتاج خبرة برمجية

---

## 📝 معلومات مهمة لملف APK

### معلومات التطبيق:
- **Package ID**: `com.abdulrahman.suhaila.wedding`
- **اسم التطبيق**: ذكرى الزواج
- **الإصدار**: 1.0.0
- **الحجم التقريبي**: 2-5 MB
- **الصلاحيات المطلوبة**: الإنترنت فقط

### متطلبات التشغيل:
- Android 5.0 (API 21) فما فوق
- مساحة فارغة: 10 MB
- اتصال بالإنترنت (للمرة الأولى فقط)

---

## 🔧 تثبيت APK على الهاتف

### خطوات التثبيت:

1. **تفعيل المصادر غير المعروفة**:
   - اذهب إلى الإعدادات
   - الأمان أو Security
   - فعّل "Unknown Sources" أو "Install unknown apps"

2. **نقل ملف APK**:
   - انقل الملف للهاتف عبر USB أو WhatsApp
   - أو ارفعه على Google Drive وانزله

3. **التثبيت**:
   - افتح مدير الملفات
   - ابحث عن ملف APK
   - اضغط عليه
   - اضغط "Install"
   - انتظر التثبيت
   - اضغط "Open"

---

## ⚠️ ملاحظات مهمة

1. **الشهادة الرقمية**: APK غير موقع رقمياً، قد يظهر تحذير عند التثبيت
2. **التحديثات**: لتحديث التطبيق، يجب إعادة إنشاء APK
3. **الأمان**: لا تشارك APK من مصادر غير موثوقة
4. **Google Play**: لرفع التطبيق على المتجر، تحتاج حساب مطور ($25)

---

## 🌟 نصائح للحصول على أفضل نتيجة

1. استخدم PWABuilder للحصول على APK احترافي
2. اختبر التطبيق على عدة أجهزة
3. تأكد من أن جميع الروابط والصور تعمل
4. احتفظ بنسخة من APK للمشاركة

---

## 📤 مشاركة التطبيق

بعد إنشاء APK يمكنك:
- إرساله عبر WhatsApp
- رفعه على Google Drive
- مشاركته عبر Telegram
- رفعه على موقع خاص

---

## ✅ التحقق من نجاح التثبيت

بعد التثبيت تأكد من:
- ظهور الأيقونة على الشاشة الرئيسية
- فتح التطبيق بدون مشاكل
- عمل العد التنازلي بشكل صحيح
- ظهور الأسماء والتاريخ