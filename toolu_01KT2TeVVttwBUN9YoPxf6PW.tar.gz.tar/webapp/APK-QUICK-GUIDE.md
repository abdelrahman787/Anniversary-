# 🚀 دليل سريع لإنشاء APK في 5 دقائق

## الطريقة السريعة (PWABuilder):

### 1️⃣ افتح الموقع:
**https://www.pwabuilder.com**

### 2️⃣ الصق الرابط:
```
https://3000-inr2tnb1kga0jf2fmmieo-6532622b.e2b.dev
```

### 3️⃣ اضغط Start

### 4️⃣ انتظر التحليل (30 ثانية)

### 5️⃣ اضغط "Package for stores"

### 6️⃣ اختر Android

### 7️⃣ املأ البيانات:
- **Package ID**: `com.wedding.app`
- **App name**: `ذكرى الزواج`
- **Version**: `1.0`

### 8️⃣ اضغط Generate

### 9️⃣ انزل الملف (Download)

### 🎉 مبروك! APK جاهز

---

## تثبيت APK على الهاتف:

1. **انقل الملف للهاتف** (WhatsApp أو USB)
2. **فعّل Unknown Sources** من الإعدادات
3. **افتح الملف واضغط Install**
4. **افتح التطبيق من الشاشة الرئيسية**

---

## روابط بديلة لإنشاء APK:

### خيار 2: AppsGeyser
- **الموقع**: https://appsgeyser.com
- **اختر**: Website → أدخل الرابط → Create

### خيار 3: Web2APK  
- **الموقع**: https://www.web2apk.com
- **أدخل**: الرابط → Generate APK

---

## 📱 معلومات التطبيق:
- **الرابط**: https://3000-inr2tnb1kga0jf2fmmieo-6532622b.e2b.dev
- **الحجم**: ~3 MB
- **Android**: 5.0+
- **الصلاحيات**: الإنترنت فقط

---

## ⚡ نصيحة سريعة:
استخدم **PWABuilder** - الأسرع والأسهل ومجاني 100%

---

✅ **النتيجة**: ملف APK جاهز للتثبيت على أي هاتف Android!