#!/bin/bash

echo "🚀 تجهيز التطبيق لإنشاء APK..."
echo "================================"

# Build the project
echo "📦 بناء المشروع..."
npm run build

# Create a deployment info file
echo "📝 إنشاء معلومات النشر..."
cat > deployment-info.txt << EOF
=================================
معلومات التطبيق للنشر كـ APK
=================================

🌐 رابط التطبيق:
https://3000-inr2tnb1kga0jf2fmmieo-6532622b.e2b.dev

📱 معلومات APK:
- Package ID: com.abdulrahman.suhaila.wedding
- اسم التطبيق: ذكرى الزواج
- الإصدار: 1.0.0
- التوجه: Portrait (عمودي)

🎨 الأيقونات:
- 512x512: /icon-512.png
- 192x192: /icon-192.png
- 144x144: /icon-144.png

✅ المميزات المفعلة:
- PWA Support
- Offline Mode
- Install Prompt
- Service Worker

📋 خطوات إنشاء APK:
1. اذهب إلى https://www.pwabuilder.com
2. أدخل الرابط أعلاه
3. اختر Android
4. انزل APK

=================================
EOF

echo "✅ تم التجهيز بنجاح!"
echo ""
echo "📱 لإنشاء ملف APK:"
echo "1. اذهب إلى: https://www.pwabuilder.com"
echo "2. أدخل: https://3000-inr2tnb1kga0jf2fmmieo-6532622b.e2b.dev"
echo "3. اتبع الخطوات في الموقع"
echo ""
echo "📖 لمزيد من التفاصيل، اقرأ: create-apk-guide.md"