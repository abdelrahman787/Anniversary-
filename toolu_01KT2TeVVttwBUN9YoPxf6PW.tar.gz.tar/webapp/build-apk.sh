#!/bin/bash

echo "🚀 بناء تطبيق Android APK..."
echo "================================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if android folder exists
if [ ! -d "android" ]; then
    echo -e "${RED}❌ مجلد Android غير موجود. تشغيل cap add android...${NC}"
    npx cap add android
fi

# Sync the web app with Android
echo -e "${YELLOW}📦 مزامنة التطبيق مع Android...${NC}"
npx cap sync android

# Navigate to android folder
cd android

# Check if gradlew exists
if [ ! -f "gradlew" ]; then
    echo -e "${YELLOW}🔧 إعداد Gradle wrapper...${NC}"
    gradle wrapper
fi

# Make gradlew executable
chmod +x gradlew

# Clean previous builds
echo -e "${YELLOW}🧹 تنظيف البناءات السابقة...${NC}"
./gradlew clean

# Build debug APK
echo -e "${YELLOW}🔨 بناء Debug APK...${NC}"
./gradlew assembleDebug

# Check if build was successful
if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo -e "${GREEN}✅ تم بناء APK بنجاح!${NC}"
    echo -e "${GREEN}📱 موقع APK:${NC}"
    echo "$(pwd)/app/build/outputs/apk/debug/app-debug.apk"
    
    # Copy APK to root directory
    cp app/build/outputs/apk/debug/app-debug.apk ../WeddingCountdown.apk
    echo -e "${GREEN}✅ تم نسخ APK إلى: WeddingCountdown.apk${NC}"
    
    # Show APK size
    SIZE=$(ls -lh ../WeddingCountdown.apk | awk '{print $5}')
    echo -e "${GREEN}📊 حجم APK: $SIZE${NC}"
else
    echo -e "${RED}❌ فشل بناء APK${NC}"
    exit 1
fi

echo ""
echo "================================"
echo -e "${GREEN}🎉 تم! APK جاهز للتثبيت${NC}"
echo "================================"
echo ""
echo "📱 لتثبيت APK على الهاتف:"
echo "1. انقل WeddingCountdown.apk إلى الهاتف"
echo "2. فعّل 'Unknown Sources' من الإعدادات"
echo "3. افتح الملف واضغط Install"