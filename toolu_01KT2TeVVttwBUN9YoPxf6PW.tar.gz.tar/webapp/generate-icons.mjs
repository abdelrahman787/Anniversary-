import sharp from 'sharp';

// Create a simple colored square as PNG icon
async function generateIcons() {
  // Create a buffer with a colored gradient background
  const width = 512;
  const height = 512;
  
  // Create SVG with gradient background and heart
  const svg = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#e55d87;stop-opacity:1" />
          <stop offset="100%" style="stop-color:#5fc3e4;stop-opacity:1" />
        </linearGradient>
      </defs>
      <rect width="${width}" height="${height}" rx="100" fill="url(#gradient)"/>
      <text x="256" y="200" font-family="Arial" font-size="120" font-weight="bold" text-anchor="middle" fill="white">💕</text>
      <text x="256" y="320" font-family="Arial" font-size="60" font-weight="bold" text-anchor="middle" fill="white">13</text>
      <text x="256" y="400" font-family="Arial" font-size="40" text-anchor="middle" fill="white">Dec</text>
    </svg>
  `;
  
  // Generate 512x512 icon
  await sharp(Buffer.from(svg))
    .png()
    .toFile('public/icon-512.png');
  
  console.log('Created icon-512.png');
  
  // Generate 192x192 icon
  await sharp(Buffer.from(svg))
    .resize(192, 192)
    .png()
    .toFile('public/icon-192.png');
  
  console.log('Created icon-192.png');
  
  // Generate 144x144 icon for older devices
  await sharp(Buffer.from(svg))
    .resize(144, 144)
    .png()
    .toFile('public/icon-144.png');
  
  console.log('Created icon-144.png');
  
  // Generate favicon
  await sharp(Buffer.from(svg))
    .resize(32, 32)
    .png()
    .toFile('public/favicon.png');
  
  console.log('Created favicon.png');
}

generateIcons().catch(console.error);